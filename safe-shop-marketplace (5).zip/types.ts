
export enum ProductCondition {
  NEW = 'Novo',
  LIKE_NEW = 'Semi-novo',
  USED_GOOD = 'Usado (Bom)',
  USED_FAIR = 'Usado (Aceitável)'
}

export enum ProductStatus {
  PENDING = 'Pendente',
  APPROVED = 'Aprovado',
  SOLD = 'Vendido',
  REJECTED = 'Rejeitado'
}

export enum PaymentStatus {
  AWAITING = 'Aguardando',
  PAID_HELD = 'Pago (Retido)',
  RELEASED = 'Liberado ao Vendedor',
  REFUNDED = 'Estornado'
}

export enum DeliveryStatus {
  PREPARING = 'Preparando',
  SHIPPED = 'Enviado',
  DELIVERED = 'Entregue'
}

export interface User {
  id: string;
  name: string;
  email: string;
  password?: string;
  isAdmin?: boolean;
  walletBalance: number;
  strikes: number;
  isBanned: boolean;
}

export interface Product {
  id: string;
  sellerId: string;
  title: string;
  description: string;
  price: number;
  condition: ProductCondition;
  status: ProductStatus;
  videoUrl: string;
  images: string[];
  category?: string;
  isNSFW?: boolean;
}

export interface CartItem extends Product {
  quantity: number;
}

export interface Order {
  id: string;
  buyerId: string;
  sellerId: string;
  productId: string;
  amount: number;
  paymentStatus: PaymentStatus;
  deliveryStatus: DeliveryStatus;
  trackingCode?: string;
  createdAt: string;
}
