
import React, { useState, useEffect } from 'react';
import { HashRouter, Routes, Route, Link, Navigate } from 'react-router-dom';
import { 
  ShieldCheck, 
  Search, 
  PlusCircle, 
  ShoppingBag,
  Bell,
  HelpCircle,
  Menu,
  User as UserIcon,
  Store,
  Zap,
  Download,
  Smartphone,
  X,
  Share,
  Sparkles,
  Lock,
  LogOut,
  Settings,
  ShoppingCart,
  Ticket,
  AlertTriangle,
  ShieldAlert,
  Moon,
  Sun
} from 'lucide-react';
import Home from './pages/Home';
import ProductDetails from './pages/ProductDetails';
import SellProduct from './pages/SellProduct';
import MyOrders from './pages/MyOrders';
import SellerDashboard from './pages/SellerDashboard';
import Login from './pages/Login';
import Register from './pages/Register';
import AdminDashboard from './pages/AdminDashboard';
import Cart from './pages/Cart';
import AIChatSupport from './components/AIChatSupport';
import WhatsAppButton from './components/WhatsAppButton';
import { Product, Order, User, ProductCondition, ProductStatus, CartItem } from './types';

const ADMIN_EMAILS = ['Edinaldogeorgez@gmail.com', 'Jonasgeorges730@gmail.com'];

const INITIAL_PRODUCTS: Product[] = [
  {
    id: 'test-item-1',
    sellerId: 'u2',
    title: 'item de teste',
    description: 'Este é um item de teste padrão.',
    price: 15.00,
    condition: ProductCondition.NEW,
    status: ProductStatus.APPROVED,
    videoUrl: 'https://sample-videos.com/video123/mp4/720/big_buck_bunny_720p_1mb.mp4',
    images: ['https://picsum.photos/seed/safe-test/800/600'],
    category: 'Tecnologia'
  },
  {
    id: 'weapon-test',
    sellerId: 'u3',
    title: 'Item Tático Especial (Permitido)',
    description: 'Item para colecionadores e segurança. Regras 18+ aplicadas.',
    price: 450.00,
    condition: ProductCondition.NEW,
    status: ProductStatus.APPROVED,
    videoUrl: 'https://sample-videos.com/video123/mp4/720/big_buck_bunny_720p_1mb.mp4',
    images: ['https://images.unsplash.com/photo-1595039838779-f313927626ed?auto=format&fit=crop&q=80&w=800'],
    category: 'Esportes',
    isNSFW: true
  }
];

const App: React.FC = () => {
  const [currentUser, setCurrentUser] = useState<User | null>(() => {
    const saved = localStorage.getItem('safe_shop_user');
    return saved ? JSON.parse(saved) : null;
  });

  const [isDarkMode, setIsDarkMode] = useState<boolean>(() => {
    return localStorage.getItem('safe_shop_theme') === 'dark';
  });
  
  const [products, setProducts] = useState<Product[]>(() => {
    const saved = localStorage.getItem('safe_shop_products');
    return saved ? JSON.parse(saved) : INITIAL_PRODUCTS;
  });

  const [orders, setOrders] = useState<Order[]>(() => {
    const saved = localStorage.getItem('safe_shop_orders');
    return saved ? JSON.parse(saved) : [];
  });

  const [cart, setCart] = useState<CartItem[]>(() => {
    const saved = localStorage.getItem('safe_shop_cart');
    return saved ? JSON.parse(saved) : [];
  });

  const [availableCoupons, setAvailableCoupons] = useState<number[]>(() => {
    const saved = localStorage.getItem('safe_shop_coupons');
    return saved ? JSON.parse(saved) : [];
  });

  useEffect(() => {
    if (isDarkMode) {
      document.documentElement.classList.add('dark');
      localStorage.setItem('safe_shop_theme', 'dark');
    } else {
      document.documentElement.classList.remove('dark');
      localStorage.setItem('safe_shop_theme', 'light');
    }
  }, [isDarkMode]);

  useEffect(() => {
    localStorage.setItem('safe_shop_products', JSON.stringify(products));
  }, [products]);

  useEffect(() => {
    localStorage.setItem('safe_shop_orders', JSON.stringify(orders));
  }, [orders]);

  useEffect(() => {
    localStorage.setItem('safe_shop_cart', JSON.stringify(cart));
  }, [cart]);

  useEffect(() => {
    localStorage.setItem('safe_shop_coupons', JSON.stringify(availableCoupons));
  }, [availableCoupons]);

  useEffect(() => {
    if (currentUser) {
      localStorage.setItem('safe_shop_user', JSON.stringify(currentUser));
    }
  }, [currentUser]);

  const onStrikeReceived = () => {
    if (!currentUser) return;
    const newStrikes = currentUser.strikes + 1;
    const isBanned = newStrikes >= 3;
    setCurrentUser({ ...currentUser, strikes: newStrikes, isBanned });
  };

  const addCoupon = (discount: number) => {
    setAvailableCoupons(prev => [...prev, discount]);
  };

  const addToCart = (product: Product) => {
    setCart(prev => {
      const existing = prev.find(item => item.id === product.id);
      if (existing) {
        return prev.map(item => item.id === product.id ? { ...item, quantity: item.quantity + 1 } : item);
      }
      return [...prev, { ...product, quantity: 1 }];
    });
  };

  const removeFromCart = (productId: string) => {
    setCart(prev => prev.filter(item => item.id !== productId));
  };

  const handleLogin = (user: User) => {
    const isAdmin = ADMIN_EMAILS.includes(user.email);
    const userWithAdmin = { ...user, isAdmin };
    setCurrentUser(userWithAdmin);
  };

  const handleLogout = () => {
    setCurrentUser(null);
    localStorage.removeItem('safe_shop_user');
  };

  if (currentUser?.isBanned) {
    return (
      <div className="min-h-screen bg-red-600 flex flex-col items-center justify-center p-6 text-center text-white">
        <ShieldAlert size={80} className="mb-6 animate-pulse" />
        <h1 className="text-4xl font-black uppercase italic mb-4">ACESSO BLOQUEADO</h1>
        <p className="max-w-md text-lg opacity-90 font-medium">
          Sua conta foi banida permanentemente por violar as políticas de segurança da Safe-Shop (3 Strikes acumulados).
        </p>
        <button onClick={handleLogout} className="mt-10 bg-white text-red-600 px-10 py-4 rounded-full font-black uppercase tracking-widest shadow-2xl">Sair da Conta</button>
      </div>
    );
  }

  return (
    <HashRouter>
      <div className="flex flex-col min-h-screen bg-[#f5f5f5] dark:bg-gray-900 transition-colors duration-300">
        {/* Topbar */}
        <div className="bg-[#ee4d2d] dark:bg-gray-800 text-white text-[12px] py-1.5 hidden sm:block border-b border-white/10 transition-colors">
          <div className="container mx-auto px-4 flex justify-between items-center">
            <div className="flex gap-6 items-center">
              <Link to="/vendas" className="hover:text-gray-200 flex items-center gap-1.5 font-medium"><Store size={14}/> Central do Vendedor</Link>
              <Link to="/vender" className="hover:text-gray-200 font-bold underline flex items-center gap-1.5"><Zap size={14} className="fill-white"/> Venda Rápida</Link>
              {currentUser && currentUser.strikes > 0 && (
                <div className="bg-yellow-400 text-red-600 px-2 rounded font-black flex items-center gap-1 animate-pulse">
                  <AlertTriangle size={10} /> {currentUser.strikes} STRIKES
                </div>
              )}
            </div>
            <div className="flex gap-4 items-center">
              {currentUser?.isAdmin && <Link to="/admin" className="text-yellow-300 font-black">Painel Admin</Link>}
              {currentUser ? (
                <div className="flex items-center gap-4">
                  <span className="font-bold">{currentUser.name}</span>
                  <button onClick={handleLogout} className="opacity-80 hover:opacity-100">Sair</button>
                </div>
              ) : (
                <div className="font-bold border-l pl-4 border-white/20 flex gap-2 uppercase">
                  <Link to="/register">Cadastrar</Link>
                  <span>|</span>
                  <Link to="/login">Entre</Link>
                </div>
              )}
            </div>
          </div>
        </div>

        <header className="sticky top-0 z-50 bg-[#ee4d2d] dark:bg-gray-800 pb-4 sm:pt-3 shadow-lg transition-colors">
          <div className="container mx-auto px-4 flex flex-col gap-4">
            <div className="flex items-center justify-between gap-4">
              <Link to="/" className="flex items-center gap-2 group shrink-0">
                <div className="bg-white dark:bg-gray-100 p-1 rounded-lg"><ShieldCheck className="text-[#ee4d2d] w-7 h-7" /></div>
                <h1 className="text-2xl font-black text-white tracking-tighter">SAFE-SHOP</h1>
              </Link>
              
              <div className="flex-1 max-w-4xl flex items-center gap-3">
                <div className="flex-1 relative">
                  <div className="flex bg-white dark:bg-gray-700 rounded-sm p-1 shadow-md">
                    <input type="text" placeholder="Buscar produtos verificados..." className="w-full bg-transparent border-none py-2.5 px-4 outline-none text-sm dark:text-white dark:placeholder-gray-400" />
                    <button className="bg-[#ee4d2d] text-white px-8 py-2.5 rounded-sm transition-transform active:scale-95"><Search size={20} /></button>
                  </div>
                </div>
                
                <Link 
                  to="/vender" 
                  className="hidden md:flex bg-yellow-400 text-red-600 hover:bg-yellow-300 px-6 py-2.5 rounded-sm font-black text-xs items-center gap-2 shadow-[0_4px_0_rgb(202,138,4)] active:shadow-none active:translate-y-[2px] transition-all whitespace-nowrap border border-yellow-500/50"
                  title="Comece a vender agora!"
                >
                  <PlusCircle size={18} />
                  VENDA RÁPIDA
                </Link>
              </div>

              <div className="flex items-center gap-4 text-white">
                <button 
                  onClick={() => setIsDarkMode(!isDarkMode)}
                  className="p-2.5 hover:bg-white/10 rounded-full transition"
                  title="Alternar Tema"
                >
                  {isDarkMode ? <Sun size={24} /> : <Moon size={24} />}
                </button>
                <Link to="/carrinho" className="relative p-2.5 hover:bg-white/10 rounded-full transition">
                  <ShoppingCart className="w-6 h-6" />
                  {cart.length > 0 && <span className="absolute -top-1 -right-1 bg-yellow-400 text-red-600 text-[10px] font-black px-1.5 py-0.5 rounded-full border-2 border-[#ee4d2d] dark:border-gray-800">{cart.length}</span>}
                </Link>
              </div>
            </div>
          </div>
        </header>

        <main className="flex-grow">
          <Routes>
            <Route path="/" element={<Home products={products.filter(p => p.status === ProductStatus.APPROVED)} onRewardEarned={addCoupon} />} />
            <Route path="/produto/:id" element={<ProductDetails products={products} onAddToCart={addToCart} onPurchase={() => {}} />} />
            <Route path="/vender" element={currentUser ? <SellProduct onListingCreated={(p) => setProducts([p, ...products])} sellerId={currentUser.id} /> : <Navigate to="/login" />} />
            <Route path="/carrinho" element={currentUser ? <Cart cart={cart} coupons={availableCoupons} onRemove={removeFromCart} onPurchase={(o) => setOrders([o, ...orders])} onClear={() => setCart([])} onUseCoupon={(idx) => setAvailableCoupons(prev => prev.filter((_, i) => i !== idx))} /> : <Navigate to="/login" />} />
            <Route path="/minhas-compras" element={currentUser ? <MyOrders orders={orders} products={products} /> : <Navigate to="/login" />} />
            <Route path="/login" element={<Login onLogin={handleLogin} />} />
            <Route path="/register" element={<Register onRegister={handleLogin} />} />
          </Routes>
        </main>

        <AIChatSupport onStrike={onStrikeReceived} />
        <WhatsAppButton />
      </div>
    </HashRouter>
  );
};

export default App;
