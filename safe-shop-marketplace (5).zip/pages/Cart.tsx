
import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { 
  Trash2, 
  ShoppingBag, 
  ArrowLeft, 
  Ticket, 
  ShieldCheck, 
  CreditCard,
  QrCode,
  X,
  Play,
  ArrowRight,
  Zap,
  CheckCircle2
} from 'lucide-react';
import { CartItem, Order, PaymentStatus, DeliveryStatus } from '../types';

interface CartProps {
  cart: CartItem[];
  coupons: number[];
  onRemove: (id: string) => void;
  onPurchase: (order: Order) => void;
  onClear: () => void;
  onUseCoupon: (index: number) => void;
}

const Cart: React.FC<CartProps> = ({ cart, coupons, onRemove, onPurchase, onClear, onUseCoupon }) => {
  const navigate = useNavigate();
  const [selectedCouponIdx, setSelectedCouponIdx] = useState<number | null>(null);
  const [showPixModal, setShowPixModal] = useState(false);
  const [showInterstitialAd, setShowInterstitialAd] = useState(false);
  const [adTimer, setAdTimer] = useState(3);
  const [isProcessing, setIsProcessing] = useState(false);

  const subtotal = cart.reduce((acc, item) => acc + (item.price * item.quantity), 0);
  const discount = selectedCouponIdx !== null ? subtotal * (coupons[selectedCouponIdx] / 100) : 0;
  const total = subtotal - discount;

  const handleCheckout = () => {
    setShowPixModal(true);
  };

  const handlePixPayment = () => {
    setIsProcessing(true);
    setTimeout(() => {
      setShowPixModal(false);
      setShowInterstitialAd(true);
      setAdTimer(3);
      setIsProcessing(false);
    }, 2000);
  };

  useEffect(() => {
    let interval: any;
    if (showInterstitialAd && adTimer > 0) {
      interval = setInterval(() => setAdTimer(prev => prev - 1), 1000);
    }
    return () => clearInterval(interval);
  }, [showInterstitialAd, adTimer]);

  const finalizePurchase = () => {
    cart.forEach(item => {
      const newOrder: Order = {
        id: `ord-${Math.random().toString(36).substr(2, 9)}`,
        buyerId: 'u1',
        sellerId: item.sellerId,
        productId: item.id,
        amount: item.price * (1 - (discount/subtotal || 0)),
        paymentStatus: PaymentStatus.PAID_HELD,
        deliveryStatus: DeliveryStatus.PREPARING,
        createdAt: new Date().toISOString(),
      };
      onPurchase(newOrder);
    });

    if (selectedCouponIdx !== null) onUseCoupon(selectedCouponIdx);
    onClear();
    setShowInterstitialAd(false);
    navigate('/minhas-compras');
  };

  if (cart.length === 0) {
    return (
      <div className="container mx-auto px-4 py-20 text-center">
        <div className="bg-white dark:bg-gray-800 p-12 rounded-sm shadow-sm inline-block w-full max-w-md transition-colors">
           <ShoppingBag size={64} className="mx-auto text-gray-200 dark:text-gray-600 mb-6" />
           <h2 className="text-xl font-black text-gray-800 dark:text-white uppercase italic">Seu carrinho está vazio</h2>
           <p className="text-gray-500 dark:text-gray-400 text-sm mt-2 mb-8">Navegue pelas ofertas e encontre itens verificados!</p>
           <Link to="/" className="bg-[#ee4d2d] text-white px-10 py-4 rounded-sm font-black uppercase tracking-widest text-sm shadow-xl block transition-transform hover:scale-105">Começar a Comprar</Link>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-[#f5f5f5] dark:bg-gray-900 min-h-screen py-8 transition-colors">
      <div className="container mx-auto px-4 max-w-5xl">
        <div className="flex items-center gap-4 mb-8">
           <button onClick={() => navigate(-1)} className="text-gray-400 hover:text-[#ee4d2d] dark:hover:text-orange-400 transition-colors"><ArrowLeft size={24}/></button>
           <h1 className="text-2xl font-black text-gray-800 dark:text-white uppercase italic tracking-tighter">Carrinho de Compras</h1>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
           {/* Items List */}
           <div className="lg:col-span-2 space-y-4">
              {cart.map((item) => (
                <div key={item.id} className="bg-white dark:bg-gray-800 p-4 rounded-sm shadow-sm flex gap-4 items-center transition-colors">
                   <div className="w-20 h-20 bg-gray-100 dark:bg-gray-700 rounded-sm overflow-hidden shrink-0">
                      <img src={item.images[0]} alt="" className="w-full h-full object-cover" />
                   </div>
                   <div className="flex-grow">
                      <h4 className="text-sm font-medium text-gray-800 dark:text-gray-200 line-clamp-1">{item.title}</h4>
                      <p className="text-[#ee4d2d] dark:text-orange-400 font-bold text-lg mt-1">R$ {item.price.toLocaleString('pt-BR')}</p>
                      <div className="flex items-center gap-4 mt-2">
                         <span className="text-[10px] bg-gray-100 dark:bg-gray-700 px-2 py-0.5 rounded text-gray-500 dark:text-gray-400 font-bold uppercase">Quantidade: {item.quantity}</span>
                      </div>
                   </div>
                   <button onClick={() => onRemove(item.id)} className="text-gray-300 hover:text-red-500 p-2"><Trash2 size={20}/></button>
                </div>
              ))}
           </div>

           {/* Summary */}
           <div className="space-y-4">
              <div className="bg-white dark:bg-gray-800 p-6 rounded-sm shadow-sm space-y-6 transition-colors">
                 <div className="space-y-4">
                    <h3 className="text-xs font-black uppercase text-gray-400 tracking-widest border-b dark:border-gray-700 pb-4">Resumo do Pedido</h3>
                    
                    <div className="space-y-3">
                       <div className="flex justify-between text-sm">
                          <span className="text-gray-500 dark:text-gray-400">Subtotal</span>
                          <span className="font-bold text-gray-800 dark:text-white">R$ {subtotal.toLocaleString('pt-BR')}</span>
                       </div>
                       {discount > 0 && (
                         <div className="flex justify-between text-sm text-green-600 dark:text-green-400 font-bold">
                            <span>Desconto Cupom</span>
                            <span>- R$ {discount.toLocaleString('pt-BR')}</span>
                         </div>
                       )}
                       <div className="flex justify-between text-lg font-black pt-4 border-t border-gray-50 dark:border-gray-700">
                          <span className="text-gray-900 dark:text-white uppercase tracking-tighter italic">Total</span>
                          <span className="text-[#ee4d2d] dark:text-orange-400">R$ {total.toLocaleString('pt-BR')}</span>
                       </div>
                    </div>
                 </div>

                 <button 
                  onClick={handleCheckout}
                  className="w-full bg-[#ee4d2d] text-white py-4 rounded-sm font-black uppercase tracking-widest text-sm shadow-xl hover:opacity-90 transition-opacity"
                 >
                    Finalizar Compra
                 </button>
                 
                 <div className="flex items-center justify-center gap-2 text-[10px] text-gray-400 font-bold uppercase">
                    <ShieldCheck size={14} className="text-green-500" />
                    Pagamento 100% Seguro
                 </div>
              </div>
           </div>
        </div>
      </div>

      {/* PIX Modal */}
      {showPixModal && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-[300] flex items-center justify-center p-4">
           <div className="bg-white dark:bg-gray-800 rounded-2xl w-full max-w-md overflow-hidden animate-in fade-in zoom-in duration-200 transition-colors">
              <div className="shopee-gradient p-6 text-white flex justify-between items-center">
                 <div className="flex items-center gap-3">
                    <QrCode size={24} />
                    <h3 className="font-black uppercase italic tracking-tighter">Pagamento via PIX</h3>
                 </div>
                 <button onClick={() => setShowPixModal(false)}><X size={20}/></button>
              </div>
              <div className="p-8 text-center space-y-6">
                 <div className="bg-white p-4 rounded-2xl border-2 border-dashed border-gray-200 dark:border-gray-600 inline-block mx-auto">
                    <img src="https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=safeshop-pix-payment" alt="Pix QR Code" className="w-40 h-40" />
                 </div>
                 <div className="space-y-1">
                    <p className="text-[10px] font-black uppercase text-gray-400">Valor a pagar</p>
                    <p className="text-3xl font-black text-[#ee4d2d] dark:text-orange-400">R$ {total.toLocaleString('pt-BR')}</p>
                 </div>
                 <button 
                  onClick={handlePixPayment}
                  disabled={isProcessing}
                  className="w-full bg-black dark:bg-gray-700 text-white py-4 rounded-xl font-black uppercase tracking-widest text-sm shadow-xl flex items-center justify-center gap-2 transition-colors"
                 >
                    {isProcessing ? 'Processando...' : 'Confirmar Pagamento'}
                    <ArrowRight size={20} />
                 </button>
              </div>
           </div>
        </div>
      )}
    </div>
  );
};

export default Cart;