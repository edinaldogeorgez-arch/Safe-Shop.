
import React from 'react';
import { 
  Wallet, 
  TrendingUp, 
  Package, 
  CheckCircle2, 
  ArrowUpRight, 
  Video,
  AlertCircle
} from 'lucide-react';
import { Product, Order } from '../types';

interface SellerDashboardProps {
  sellerId: string;
  orders: Order[];
  products: Product[];
}

const SellerDashboard: React.FC<SellerDashboardProps> = ({ sellerId, orders, products }) => {
  const myProducts = products.filter(p => p.sellerId === sellerId);
  const mySales = orders.filter(o => o.sellerId === sellerId);
  const totalBalance = mySales.reduce((acc, o) => acc + o.amount, 0);

  return (
    <div className="bg-gray-50 min-h-screen py-12">
      <div className="container mx-auto px-4 max-w-6xl">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6 mb-12">
          <div>
            <h1 className="text-3xl font-black tracking-tight mb-2">Painel do Vendedor</h1>
            <p className="text-gray-500">Gerencie seus anúncios e saldos retidos.</p>
          </div>
          <div className="flex gap-4">
             <div className="bg-white p-4 px-8 rounded-3xl shadow-sm border border-gray-100 flex items-center gap-4">
                <div className="bg-blue-100 p-3 rounded-2xl text-blue-600">
                  <Wallet className="w-6 h-6" />
                </div>
                <div>
                   <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">Saldo Pendente</p>
                   <p className="text-xl font-black">R$ {totalBalance.toLocaleString('pt-BR')}</p>
                </div>
             </div>
             <button className="bg-blue-600 text-white p-4 px-8 rounded-3xl font-bold shadow-lg shadow-blue-100 hover:bg-blue-700 transition flex items-center gap-2">
                Solicitar Saque <ArrowUpRight className="w-5 h-5" />
             </button>
          </div>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {/* Main Sales List */}
          <div className="md:col-span-2 space-y-8">
            <section>
              <h2 className="text-xl font-bold mb-6 flex items-center gap-2">
                <TrendingUp className="w-5 h-5 text-green-600" />
                Vendas Recentes
              </h2>
              {mySales.length === 0 ? (
                <div className="bg-white rounded-3xl p-12 text-center border border-gray-100">
                  <p className="text-gray-400 font-medium">Você ainda não realizou vendas.</p>
                </div>
              ) : (
                <div className="space-y-4">
                   {mySales.map(sale => (
                     <div key={sale.id} className="bg-white p-6 rounded-3xl shadow-sm border border-gray-100 flex items-center justify-between">
                        <div className="flex items-center gap-4">
                           <div className="bg-green-50 p-3 rounded-2xl text-green-600">
                              <CheckCircle2 className="w-6 h-6" />
                           </div>
                           <div>
                              <p className="font-bold">Venda #{sale.id}</p>
                              <p className="text-xs text-gray-400">Status: {sale.paymentStatus}</p>
                           </div>
                        </div>
                        <div className="text-right">
                           <p className="font-black text-lg">R$ {sale.amount.toLocaleString('pt-BR')}</p>
                           <button className="text-blue-600 text-[10px] font-black uppercase hover:underline">Ver Detalhes</button>
                        </div>
                     </div>
                   ))}
                </div>
              )}
            </section>

            <section>
              <h2 className="text-xl font-bold mb-6 flex items-center gap-2">
                <Package className="w-5 h-5 text-blue-600" />
                Seus Anúncios
              </h2>
              <div className="grid sm:grid-cols-2 gap-4">
                {myProducts.map(product => (
                  <div key={product.id} className="bg-white p-4 rounded-3xl shadow-sm border border-gray-100 flex gap-4">
                     <div className="w-20 h-20 rounded-2xl overflow-hidden shrink-0 bg-gray-100">
                        <img src={product.images[0]} alt="" className="w-full h-full object-cover" />
                     </div>
                     <div className="flex-grow flex flex-col justify-between py-1">
                        <h4 className="font-bold text-sm line-clamp-1">{product.title}</h4>
                        <div className="flex items-center justify-between">
                           <span className="font-black text-gray-900">R$ {product.price}</span>
                           <div className="bg-red-50 text-red-600 p-1.5 rounded-lg">
                              <Video className="w-3 h-3" />
                           </div>
                        </div>
                     </div>
                  </div>
                ))}
              </div>
            </section>
          </div>

          {/* Sidebar Info */}
          <div className="space-y-6">
            <div className="bg-white rounded-[2rem] p-8 shadow-sm border border-gray-100">
               <h3 className="font-bold text-lg mb-6">Métricas de Vendedor</h3>
               <div className="space-y-6">
                  <div className="flex justify-between items-center">
                     <span className="text-sm text-gray-500 font-medium">Reputação</span>
                     <span className="text-green-600 font-black">Excelente</span>
                  </div>
                  <div className="flex justify-between items-center">
                     <span className="text-sm text-gray-500 font-medium">Tempo Médio de Envio</span>
                     <span className="text-gray-900 font-black">18 horas</span>
                  </div>
                  <div className="flex justify-between items-center">
                     <span className="text-sm text-gray-500 font-medium">Vendas Concluídas</span>
                     <span className="text-gray-900 font-black">12</span>
                  </div>
               </div>
            </div>

            <div className="bg-blue-600 rounded-[2rem] p-8 text-white">
               <AlertCircle className="w-10 h-10 mb-4 text-blue-200" />
               <h3 className="font-bold text-lg mb-2">Dica de Segurança</h3>
               <p className="text-sm text-blue-100 leading-relaxed">
                  Lembre-se: o vídeo que você postou é a garantia de que o comprador não poderá agir de má fé. 
                  Sempre poste via Safe-Shop para garantir seu seguro.
               </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SellerDashboard;
