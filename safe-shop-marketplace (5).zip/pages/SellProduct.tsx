
import React, { useState, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  Video, 
  ShieldAlert, 
  CheckCircle2, 
  Camera,
  X,
  Loader2,
  AlertCircle,
  EyeOff
} from 'lucide-react';
import { Product, ProductCondition, ProductStatus } from '../types';

interface SellProductProps {
  onListingCreated: (product: Product) => void;
  sellerId: string;
}

const SellProduct: React.FC<SellProductProps> = ({ onListingCreated, sellerId }) => {
  const navigate = useNavigate();
  const videoInputRef = useRef<HTMLInputElement>(null);
  const imageInputRef = useRef<HTMLInputElement>(null);

  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    price: '',
    condition: ProductCondition.NEW,
    isNSFW: false
  });
  const [video, setVideo] = useState<File | null>(null);
  const [images, setImages] = useState<File[]>([]);
  const [acceptedTerms, setAcceptedTerms] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!video) return alert("Vídeo obrigatório!");
    setLoading(true);
    setTimeout(() => {
      const newProduct: Product = {
        id: `p-${Math.random().toString(36).substr(2, 9)}`,
        sellerId,
        title: formData.title,
        description: formData.description,
        price: parseFloat(formData.price),
        condition: formData.condition,
        status: ProductStatus.APPROVED,
        isNSFW: formData.isNSFW,
        videoUrl: URL.createObjectURL(video),
        images: images.length > 0 ? images.map(img => URL.createObjectURL(img)) : ['https://picsum.photos/seed/placeholder/800/600']
      };
      onListingCreated(newProduct);
      setLoading(false);
      navigate('/');
    }, 1500);
  };

  return (
    <div className="bg-[#f5f5f5] min-h-screen py-8">
      <div className="container mx-auto px-4 max-w-4xl">
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="bg-white p-8 rounded-sm shadow-sm">
             <h2 className="text-sm font-bold uppercase text-gray-500 mb-6 border-b pb-4">Cadastro de Produto</h2>
             
             <div className="space-y-6">
                <div className="grid md:grid-cols-4 items-center gap-4">
                   <label className="text-xs text-gray-500">Título</label>
                   <input required value={formData.title} onChange={(e) => setFormData({...formData, title: e.target.value})} className="md:col-span-3 border p-2 text-sm outline-none" />
                </div>

                {/* NSFW Toggle */}
                <div className="grid md:grid-cols-4 items-center gap-4 bg-gray-50 p-4 rounded-sm border border-dashed">
                   <div className="flex items-center gap-2 md:col-span-1">
                      <EyeOff size={16} className="text-red-500" />
                      <span className="text-[10px] font-black uppercase text-red-500">Restrito</span>
                   </div>
                   <div className="md:col-span-3 flex items-center gap-3">
                      <label className="relative inline-flex items-center cursor-pointer">
                        <input type="checkbox" checked={formData.isNSFW} onChange={(e) => setFormData({...formData, isNSFW: e.target.checked})} className="sr-only peer" />
                        <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-red-600"></div>
                      </label>
                      <span className="text-xs text-gray-600">Este produto contém conteúdo +18 ou Armas (Foto será borrada).</span>
                   </div>
                </div>

                <div className="grid md:grid-cols-4 items-center gap-4">
                   <label className="text-xs text-gray-500">Preço</label>
                   <input required type="number" value={formData.price} onChange={(e) => setFormData({...formData, price: e.target.value})} className="md:col-span-3 border p-2 text-sm" />
                </div>

                <div className="flex gap-4">
                   <button type="button" onClick={() => videoInputRef.current?.click()} className="flex-1 border-2 border-dashed p-4 flex flex-col items-center">
                      <Video size={24} className="text-[#ee4d2d]" />
                      <span className="text-[10px] font-bold mt-1 uppercase">{video ? video.name : 'VÍDEO DE PROVA'}</span>
                   </button>
                   <input type="file" ref={videoInputRef} accept="video/*" className="hidden" onChange={(e) => e.target.files && setVideo(e.target.files[0])} />
                </div>
             </div>

             <button type="submit" className="w-full bg-[#ee4d2d] text-white py-4 mt-8 font-black uppercase tracking-widest">Publicar Agora</button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default SellProduct;
