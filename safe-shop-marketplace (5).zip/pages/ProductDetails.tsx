
import React, { useState } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { 
  ShieldCheck, 
  Video, 
  Play, 
  Info, 
  ArrowLeft,
  Truck,
  MessageCircle,
  Share2,
  Heart,
  Star,
  CheckCircle2,
  AlertTriangle,
  Flag,
  X,
  Send,
  ShoppingCart
} from 'lucide-react';
import { Product, PaymentStatus, DeliveryStatus, Order } from '../types';

interface ProductDetailsProps {
  products: Product[];
  onPurchase: (order: Order) => void;
  onAddToCart: (product: Product) => void;
}

const ProductDetails: React.FC<ProductDetailsProps> = ({ products, onPurchase, onAddToCart }) => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [showVideo, setShowVideo] = useState(false);
  const [addedMessage, setAddedMessage] = useState(false);

  const product = products.find(p => p.id === id);

  if (!product) return null;

  const handleAddToCart = () => {
    onAddToCart(product);
    setAddedMessage(true);
    setTimeout(() => setAddedMessage(false), 3000);
  };

  const handleBuyNow = () => {
    onAddToCart(product);
    navigate('/carrinho');
  };

  return (
    <div className="bg-[#f5f5f5] dark:bg-gray-900 transition-colors py-4 md:py-8 min-h-screen">
      {addedMessage && (
        <div className="fixed top-24 left-1/2 -translate-x-1/2 z-[200] bg-black/80 text-white px-6 py-3 rounded-full text-xs font-bold animate-in fade-in slide-in-from-top-4 duration-300">
           Produto adicionado ao carrinho! 🛒
        </div>
      )}

      <div className="container mx-auto px-4">
        <div className="bg-white dark:bg-gray-800 shadow-sm p-4 md:p-8 grid md:grid-cols-2 gap-8 rounded-sm transition-colors">
          {/* Media Section */}
          <div className="space-y-4">
            <div className="relative aspect-square bg-gray-100 dark:bg-gray-700 overflow-hidden border border-gray-100 dark:border-gray-700">
               {showVideo ? (
                 <video src={product.videoUrl} controls autoPlay className="w-full h-full object-contain bg-black" />
               ) : (
                 <>
                   <img src={product.images[0]} alt={product.title} className="w-full h-full object-cover" />
                   <div className="absolute inset-0 bg-black/20 flex flex-col items-center justify-center">
                      <button 
                        onClick={() => setShowVideo(true)}
                        className="bg-[#ee4d2d] w-16 h-16 rounded-full flex items-center justify-center text-white shadow-xl hover:scale-110 transition"
                      >
                        <Play size={32} fill="white" className="ml-1" />
                      </button>
                      <span className="text-white font-black text-xs mt-4 uppercase tracking-[0.2em] bg-black/40 px-3 py-1 backdrop-blur-sm rounded-sm">Ver Vídeo Real</span>
                   </div>
                 </>
               )}
            </div>
          </div>

          {/* Info Section */}
          <div className="flex flex-col">
            <h1 className="text-xl md:text-2xl font-medium text-gray-900 dark:text-white leading-tight mb-4">{product.title}</h1>
            
            <div className="bg-[#fafafa] dark:bg-gray-700/50 p-6 mb-6 rounded-sm">
               <div className="flex items-center gap-4">
                  <span className="text-3xl font-bold text-[#ee4d2d] dark:text-orange-400">R$ {product.price.toLocaleString('pt-BR')}</span>
               </div>
               <div className="mt-4 flex items-center gap-2">
                  <Truck size={16} className="text-green-600 dark:text-green-400"/>
                  <span className="text-xs text-green-600 dark:text-green-400 font-bold uppercase">Frete Grátis com Seguro</span>
               </div>
            </div>

            <div className="mt-auto grid grid-cols-1 sm:grid-cols-2 gap-4">
               <button 
                onClick={handleAddToCart}
                className="border border-[#ee4d2d] text-[#ee4d2d] bg-[#ffeee8] dark:bg-[#ee4d2d]/10 py-4 font-black rounded-sm flex items-center justify-center gap-2 hover:bg-[#fff5f1] dark:hover:bg-[#ee4d2d]/20 transition uppercase text-sm tracking-widest"
               >
                  <ShoppingCart size={20}/>
                  Adicionar ao Carrinho
               </button>
               <button 
                onClick={handleBuyNow}
                className="bg-[#ee4d2d] text-white py-4 font-black hover:opacity-90 transition rounded-sm shadow-sm uppercase text-sm tracking-widest"
               >
                  Comprar Agora
               </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProductDetails;