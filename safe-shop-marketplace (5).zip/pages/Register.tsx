
import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { User as UserIcon, Mail, Lock, ShieldCheck, ArrowRight, CheckCircle2 } from 'lucide-react';
import { User } from '../types';

interface RegisterProps {
  onRegister: (user: User) => void;
}

const Register: React.FC<RegisterProps> = ({ onRegister }) => {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    password: '',
    confirmPassword: ''
  });
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (formData.password !== formData.confirmPassword) {
      setError('As senhas não coincidem.');
      return;
    }

    setLoading(true);

    setTimeout(() => {
      const storedUsers: User[] = JSON.parse(localStorage.getItem('safe_shop_registered_users') || '[]');
      
      if (storedUsers.some(u => u.email.toLowerCase() === formData.email.toLowerCase())) {
        setError('Este e-mail já está cadastrado.');
        setLoading(false);
        return;
      }

      // Added missing strikes and isBanned properties to comply with User interface
      const newUser: User = {
        id: `u-${Math.random().toString(36).substr(2, 9)}`,
        name: formData.name,
        email: formData.email,
        password: formData.password,
        walletBalance: 0,
        strikes: 0,
        isBanned: false
      };

      const updatedUsers = [...storedUsers, newUser];
      localStorage.setItem('safe_shop_registered_users', JSON.stringify(updatedUsers));
      
      onRegister(newUser);
      setLoading(false);
      navigate('/');
    }, 1500);
  };

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col justify-center items-center p-4">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <Link to="/" className="inline-flex items-center gap-2 mb-2">
            <div className="bg-[#ee4d2d] p-2 rounded-xl text-white shadow-lg">
              <ShieldCheck size={24} />
            </div>
            <h2 className="text-2xl font-black text-[#ee4d2d] tracking-tighter">SAFE-SHOP</h2>
          </Link>
          <h1 className="text-3xl font-black text-gray-900 italic uppercase">Criar Nova Conta</h1>
          <p className="text-gray-500 text-sm mt-2">Junte-se ao marketplace mais seguro do Brasil.</p>
        </div>

        <div className="bg-white rounded-[2.5rem] shadow-2xl border border-gray-100 p-8 md:p-10 relative overflow-hidden">
          <div className="absolute top-0 right-0 p-6 opacity-5 pointer-events-none">
            <ShieldCheck size={120} />
          </div>

          <form onSubmit={handleSubmit} className="space-y-5 relative z-10">
            {error && (
              <div className="bg-red-50 text-red-600 p-4 rounded-2xl text-xs font-bold border border-red-100">
                {error}
              </div>
            )}

            <div className="space-y-1">
              <label className="text-[10px] font-black uppercase text-gray-400 tracking-widest px-2">Nome Completo</label>
              <div className="relative">
                <UserIcon className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-300" size={18} />
                <input 
                  type="text"
                  required
                  value={formData.name}
                  onChange={(e) => setFormData({...formData, name: e.target.value})}
                  placeholder="Como quer ser chamado?"
                  className="w-full bg-gray-50 border border-gray-100 p-4 pl-12 rounded-2xl outline-none focus:ring-2 focus:ring-[#ee4d2d] focus:bg-white transition-all text-sm"
                />
              </div>
            </div>

            <div className="space-y-1">
              <label className="text-[10px] font-black uppercase text-gray-400 tracking-widest px-2">E-mail</label>
              <div className="relative">
                <Mail className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-300" size={18} />
                <input 
                  type="email"
                  required
                  value={formData.email}
                  onChange={(e) => setFormData({...formData, email: e.target.value})}
                  placeholder="seu@email.com"
                  className="w-full bg-gray-50 border border-gray-100 p-4 pl-12 rounded-2xl outline-none focus:ring-2 focus:ring-[#ee4d2d] focus:bg-white transition-all text-sm"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-1">
                <label className="text-[10px] font-black uppercase text-gray-400 tracking-widest px-2">Senha</label>
                <div className="relative">
                  <Lock className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-300" size={18} />
                  <input 
                    type="password"
                    required
                    value={formData.password}
                    onChange={(e) => setFormData({...formData, password: e.target.value})}
                    placeholder="••••••"
                    className="w-full bg-gray-50 border border-gray-100 p-4 pl-12 rounded-2xl outline-none focus:ring-2 focus:ring-[#ee4d2d] focus:bg-white transition-all text-sm"
                  />
                </div>
              </div>
              <div className="space-y-1">
                <label className="text-[10px] font-black uppercase text-gray-400 tracking-widest px-2">Confirmar</label>
                <div className="relative">
                  <Lock className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-300" size={18} />
                  <input 
                    type="password"
                    required
                    value={formData.confirmPassword}
                    onChange={(e) => setFormData({...formData, confirmPassword: e.target.value})}
                    placeholder="••••••"
                    className="w-full bg-gray-50 border border-gray-100 p-4 pl-12 rounded-2xl outline-none focus:ring-2 focus:ring-[#ee4d2d] focus:bg-white transition-all text-sm"
                  />
                </div>
              </div>
            </div>

            <div className="bg-gray-50 p-4 rounded-2xl border border-dashed border-gray-200">
               <div className="flex items-center gap-3">
                  <CheckCircle2 size={16} className="text-green-500 shrink-0" />
                  <p className="text-[10px] text-gray-500 font-medium">Sua conta terá automaticamente o sistema de <span className="font-bold text-gray-700">Safe Pay</span> ativado.</p>
               </div>
            </div>

            <button 
              type="submit"
              disabled={loading}
              className="w-full bg-black text-white py-4 rounded-2xl font-black uppercase tracking-widest hover:bg-[#ee4d2d] transition-all flex items-center justify-center gap-2 mt-4 shadow-xl shadow-gray-200"
            >
              {loading ? 'Criando Conta...' : 'Cadastrar Grátis'}
              <ArrowRight size={20} />
            </button>
          </form>

          <div className="mt-8 text-center">
            <p className="text-sm text-gray-500 font-medium">
              Já tem uma conta?{' '}
              <Link to="/login" className="text-[#ee4d2d] font-black uppercase tracking-tighter">
                Faça Login
              </Link>
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Register;
