
import React, { useState, useMemo, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { 
  Video, 
  ArrowRight, 
  Zap, 
  ShieldCheck, 
  Truck, 
  RotateCcw, 
  PlusCircle, 
  Store, 
  Sparkles, 
  Download,
  Filter,
  X,
  ChevronDown,
  Search,
  Ticket,
  Play,
  EyeOff,
  ShoppingBag,
  Clock
} from 'lucide-react';
import { Product, ProductCondition } from '../types';

interface HomeProps {
  products: Product[];
  onDownloadApp?: () => void;
  onRewardEarned: (discount: number) => void;
}

const Home: React.FC<HomeProps> = ({ products, onDownloadApp, onRewardEarned }) => {
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [minPrice, setMinPrice] = useState<string>('');
  const [maxPrice, setMaxPrice] = useState<string>('');
  
  const filteredProducts = useMemo(() => {
    return products.filter(p => {
      const matchCategory = !selectedCategory || p.category === selectedCategory;
      const matchMinPrice = !minPrice || p.price >= parseFloat(minPrice);
      const matchMaxPrice = !maxPrice || p.price <= parseFloat(maxPrice);
      return matchCategory && matchMinPrice && matchMaxPrice;
    });
  }, [products, selectedCategory, minPrice, maxPrice]);

  return (
    <div className="space-y-6">
      {/* Quick Sell Hero Section */}
      <section className="bg-gradient-to-r from-[#ee4d2d] to-orange-500 dark:from-gray-800 dark:to-gray-900 py-10 text-white overflow-hidden relative border-b border-orange-600/20">
        <div className="absolute top-0 right-0 p-12 opacity-10 transform translate-x-1/4 -translate-y-1/4">
          <Store size={320} />
        </div>
        <div className="container mx-auto px-4 relative z-10">
          <div className="max-w-3xl">
            <div className="inline-flex items-center gap-2 bg-white/20 backdrop-blur-md px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-widest mb-4">
              <Sparkles size={12} className="text-yellow-300" />
              O marketplace mais seguro do Brasil
            </div>
            <h1 className="text-4xl md:text-5xl font-black italic uppercase leading-tight tracking-tighter mb-6">
              Venda seus produtos <br />
              <span className="text-yellow-300">com segurança total</span>
            </h1>
            <p className="text-lg opacity-90 mb-8 max-w-xl font-medium leading-relaxed">
              Receba pagamentos garantidos, verificação por vídeo obrigatória e suporte 24h via IA Sentinela.
            </p>
            <div className="flex flex-wrap gap-4">
              <Link 
                to="/vender" 
                className="bg-yellow-400 text-[#ee4d2d] px-10 py-5 rounded-sm font-black uppercase tracking-widest text-sm shadow-[0_6px_0_rgb(202,138,4)] hover:shadow-[0_4px_0_rgb(202,138,4)] active:shadow-none hover:bg-yellow-300 active:translate-y-1 transition-all flex items-center gap-3"
              >
                <PlusCircle size={22} />
                Venda Rápida Agora
              </Link>
              <div className="hidden sm:flex items-center gap-3 px-6 py-4 bg-white/10 backdrop-blur-sm rounded-sm border border-white/20">
                <ShieldCheck size={24} className="text-green-300" />
                <div className="text-left">
                  <p className="text-[10px] font-black uppercase leading-none mb-1">Proteção</p>
                  <p className="text-xs font-bold opacity-80">Safe Pay Ativo</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Main Content Area */}
      <section className="bg-white dark:bg-gray-800 transition-colors pb-10 pt-4">
        <div className="container mx-auto px-4">
           <div className="border-b-4 border-[#ee4d2d] w-fit mb-8 flex items-center gap-3">
              <Zap className="text-[#ee4d2d] fill-[#ee4d2d]" size={24} />
              <h2 className="text-2xl font-black uppercase tracking-wider text-[#ee4d2d] dark:text-orange-400 pb-2">Destaques do Dia</h2>
           </div>

           {filteredProducts.length === 0 ? (
             <div className="text-center py-20 bg-gray-50 dark:bg-gray-700 rounded-sm">
                <ShoppingBag size={64} className="mx-auto text-gray-200 dark:text-gray-600 mb-4" />
                <p className="text-gray-500 dark:text-gray-400 font-bold uppercase italic">Nenhum produto encontrado</p>
             </div>
           ) : (
             <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
                {filteredProducts.map((product) => (
                  <Link to={`/produto/${product.id}`} key={product.id} className="bg-white dark:bg-gray-700 rounded-sm overflow-hidden shadow-sm hover:shadow-xl transition-all border border-transparent hover:border-[#ee4d2d] group relative flex flex-col h-full">
                    <div className="relative aspect-square overflow-hidden bg-gray-100 dark:bg-gray-600">
                      <img 
                        src={product.images[0]} 
                        alt={product.title} 
                        className={`w-full h-full object-cover transition-all duration-500 group-hover:scale-110 ${product.isNSFW ? 'blur-2xl scale-110 grayscale' : ''}`} 
                      />
                      
                      {product.isNSFW && (
                        <div className="absolute inset-0 flex flex-col items-center justify-center bg-black/40 p-2 text-center">
                          <EyeOff size={24} className="text-white mb-1" />
                          <span className="text-[8px] font-black text-white uppercase leading-tight">Conteúdo Restrito (+18)</span>
                          <span className="text-[7px] text-white/80 mt-1">Clique para Ver</span>
                        </div>
                      )}

                      <div className="absolute top-2 left-0 flex flex-col gap-1 items-start">
                        <span className="bg-[#ee4d2d] text-white text-[9px] font-black px-2 py-0.5 uppercase tracking-tighter">FRETE GRÁTIS</span>
                      </div>
                      
                      <div className="absolute bottom-2 right-2 bg-black/60 backdrop-blur-md p-1.5 rounded-full text-white scale-0 group-hover:scale-100 transition-transform">
                        <Play size={12} fill="white" />
                      </div>
                    </div>
                    
                    <div className="p-3 space-y-2 flex-grow flex flex-col">
                      <h3 className="text-[12px] text-gray-800 dark:text-gray-100 line-clamp-2 leading-tight h-8 font-medium">
                        {product.title}
                      </h3>
                      <div className="mt-auto">
                        <div className="flex items-center gap-1 mb-1">
                          <div className="flex">
                            {[1,2,3,4,5].map(i => <Sparkles key={i} size={8} className="text-yellow-400 fill-yellow-400" />)}
                          </div>
                          <span className="text-[8px] text-gray-400 font-bold uppercase">(24 vendidos)</span>
                        </div>
                        <div className="flex items-end justify-between">
                          <span className="text-lg font-black text-[#ee4d2d] dark:text-orange-400 tracking-tighter">R$ {product.price.toLocaleString('pt-BR')}</span>
                        </div>
                      </div>
                    </div>
                  </Link>
                ))}
             </div>
           )}
        </div>
      </section>
    </div>
  );
};

export default Home;
