
import React from 'react';
import { Link } from 'react-router-dom';
import { 
  Package, 
  Truck, 
  CheckCircle, 
  Clock, 
  ShieldCheck, 
  ChevronRight,
  ExternalLink
} from 'lucide-react';
import { Order, Product, PaymentStatus, DeliveryStatus } from '../types';

interface MyOrdersProps {
  orders: Order[];
  products: Product[];
}

const MyOrders: React.FC<MyOrdersProps> = ({ orders, products }) => {
  const getProduct = (id: string) => products.find(p => p.id === id);

  return (
    <div className="bg-gray-50 min-h-screen py-12">
      <div className="container mx-auto px-4 max-w-5xl">
        <div className="mb-10">
          <h1 className="text-3xl font-black tracking-tight mb-2">Minhas Compras</h1>
          <p className="text-gray-500">Acompanhe seus pedidos e o status do seu pagamento seguro.</p>
        </div>

        {orders.length === 0 ? (
          <div className="bg-white rounded-[2rem] p-12 text-center shadow-sm border border-gray-100">
            <div className="bg-gray-50 w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-6">
              <Package className="w-10 h-10 text-gray-300" />
            </div>
            <h2 className="text-xl font-bold mb-2">Nenhuma compra ainda</h2>
            <p className="text-gray-500 mb-8">Comece a explorar produtos verificados com segurança.</p>
            <Link to="/" className="bg-blue-600 text-white px-8 py-3 rounded-full font-bold hover:bg-blue-700 transition">
              Ver Ofertas
            </Link>
          </div>
        ) : (
          <div className="space-y-6">
            {orders.map((order) => {
              const product = getProduct(order.productId);
              return (
                <div key={order.id} className="bg-white rounded-[2rem] overflow-hidden shadow-sm border border-gray-100 group hover:shadow-md transition">
                  <div className="p-6 md:p-8 flex flex-col md:flex-row gap-6 md:items-center">
                    <div className="w-32 h-32 rounded-2xl overflow-hidden bg-gray-100 shrink-0">
                      <img src={product?.images[0]} alt={product?.title} className="w-full h-full object-cover" />
                    </div>
                    
                    <div className="flex-grow">
                      <div className="flex items-center gap-2 mb-2">
                        <span className="text-[10px] font-black uppercase text-blue-600 tracking-widest">Pedido #{order.id}</span>
                        <div className="h-1 w-1 bg-gray-300 rounded-full"></div>
                        <span className="text-xs text-gray-400">{new Date(order.createdAt).toLocaleDateString()}</span>
                      </div>
                      <h3 className="text-xl font-bold mb-4">{product?.title}</h3>
                      
                      <div className="flex flex-wrap gap-4">
                        <div className="flex items-center gap-2 px-3 py-1.5 bg-green-50 rounded-full">
                          <ShieldCheck className="w-4 h-4 text-green-600" />
                          <span className="text-xs font-bold text-green-700">Pagamento Retido (Safe Pay)</span>
                        </div>
                        <div className="flex items-center gap-2 px-3 py-1.5 bg-blue-50 rounded-full">
                          <Clock className="w-4 h-4 text-blue-600" />
                          <span className="text-xs font-bold text-blue-700">Preparando Envio</span>
                        </div>
                      </div>
                    </div>

                    <div className="md:text-right flex flex-col justify-between h-full">
                      <div className="text-2xl font-black text-gray-900 mb-4 md:mb-0">
                        R$ {order.amount.toLocaleString('pt-BR')}
                      </div>
                      <button className="flex items-center gap-2 bg-gray-50 text-gray-700 px-6 py-2.5 rounded-xl text-sm font-bold hover:bg-blue-600 hover:text-white transition">
                        Detalhes do Rastreio
                        <ChevronRight className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                  
                  {/* Status Timeline Bar */}
                  <div className="bg-gray-50 border-t border-gray-100 px-8 py-4 flex items-center justify-between">
                    <div className="flex-grow flex items-center">
                      <div className="flex flex-col items-center">
                        <div className="w-4 h-4 rounded-full bg-blue-600 ring-4 ring-blue-100"></div>
                        <span className="text-[10px] font-bold mt-1 text-blue-600">PAGO</span>
                      </div>
                      <div className="h-0.5 bg-blue-600 flex-grow mx-2"></div>
                      <div className="flex flex-col items-center">
                        <div className="w-4 h-4 rounded-full bg-blue-600 animate-pulse"></div>
                        <span className="text-[10px] font-bold mt-1 text-blue-600">ENVIO</span>
                      </div>
                      <div className="h-0.5 bg-gray-200 flex-grow mx-2"></div>
                      <div className="flex flex-col items-center">
                        <div className="w-4 h-4 rounded-full bg-gray-200"></div>
                        <span className="text-[10px] font-bold mt-1 text-gray-400">ENTREGA</span>
                      </div>
                    </div>
                    <div className="ml-8 hidden sm:flex items-center gap-2 text-xs text-blue-600 font-bold">
                       <Truck className="w-4 h-4" />
                       O vendedor tem 48h para postar.
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};

export default MyOrders;
