
import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { Mail, Lock, ShieldCheck, Eye, EyeOff, AlertCircle, ArrowRight } from 'lucide-react';
import { User } from '../types';

interface LoginProps {
  onLogin: (user: User) => void;
}

const Login: React.FC<LoginProps> = ({ onLogin }) => {
  const navigate = useNavigate();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState('');
  const [isResetting, setIsResetting] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    // Em uma aplicação real, aqui haveria uma chamada de API.
    // Simulamos buscando do localStorage ou hardcoded admins
    const storedUsers: User[] = JSON.parse(localStorage.getItem('safe_shop_registered_users') || '[]');
    
    // Hardcoded Admins
    const admins = [
      { id: 'admin-1', name: 'Edinaldo Georgez', email: 'Edinaldogeorgez@gmail.com', password: 'admin', walletBalance: 10000 },
      { id: 'admin-2', name: 'Jonas Georges', email: 'Jonasgeorges730@gmail.com', password: 'admin', walletBalance: 10000 }
    ];

    const allUsers = [...admins, ...storedUsers];
    const user = allUsers.find(u => u.email.toLowerCase() === email.toLowerCase() && u.password === password);

    if (user) {
      onLogin(user);
      navigate('/');
    } else {
      setError('E-mail ou senha incorretos. Verifique seus dados.');
    }
  };

  const handleResetPassword = () => {
    if (!email) {
      setError('Insira seu e-mail para recuperar a senha.');
      return;
    }
    setError('');
    setIsResetting(true);
    setTimeout(() => {
      setIsResetting(false);
      alert(`Link de recuperação enviado para ${email}. Verifique sua caixa de entrada.`);
    }, 2000);
  };

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col justify-center items-center p-4">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <Link to="/" className="inline-flex items-center gap-2 mb-4">
            <div className="bg-[#ee4d2d] p-2 rounded-xl text-white shadow-lg">
              <ShieldCheck size={32} />
            </div>
            <h2 className="text-3xl font-black text-[#ee4d2d] tracking-tighter">SAFE-SHOP</h2>
          </Link>
          <p className="text-gray-500 font-medium">Onde a segurança por vídeo é a prioridade.</p>
        </div>

        <div className="bg-white rounded-3xl shadow-xl border border-gray-100 p-8">
          <h3 className="text-xl font-black text-gray-800 mb-6 uppercase tracking-tight italic">Entre na sua Conta</h3>
          
          {error && (
            <div className="bg-red-50 text-red-600 p-4 rounded-2xl flex items-center gap-3 mb-6 text-sm font-medium animate-pulse border border-red-100">
              <AlertCircle size={20} />
              {error}
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-5">
            <div className="space-y-2">
              <label className="text-[10px] font-black uppercase text-gray-400 tracking-widest px-1">Seu E-mail</label>
              <div className="relative">
                <Mail className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-300" size={20} />
                <input 
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="exemplo@gmail.com"
                  className="w-full bg-gray-50 border border-gray-100 p-4 pl-12 rounded-2xl outline-none focus:ring-2 focus:ring-[#ee4d2d] focus:bg-white transition-all text-sm"
                />
              </div>
            </div>

            <div className="space-y-2">
              <div className="flex justify-between items-center px-1">
                <label className="text-[10px] font-black uppercase text-gray-400 tracking-widest">Sua Senha</label>
                <button 
                  type="button"
                  onClick={handleResetPassword}
                  className="text-[10px] font-black text-[#ee4d2d] uppercase hover:underline"
                >
                  Esqueci a Senha
                </button>
              </div>
              <div className="relative">
                <Lock className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-300" size={20} />
                <input 
                  type={showPassword ? "text" : "password"}
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full bg-gray-50 border border-gray-100 p-4 pl-12 pr-12 rounded-2xl outline-none focus:ring-2 focus:ring-[#ee4d2d] focus:bg-white transition-all text-sm"
                />
                <button 
                  type="button" 
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-400 hover:text-[#ee4d2d]"
                >
                  {showPassword ? <EyeOff size={20} /> : <Eye size={20} />}
                </button>
              </div>
            </div>

            <button 
              type="submit"
              className="w-full bg-[#ee4d2d] text-white py-4 rounded-2xl font-black uppercase tracking-widest shadow-xl shadow-orange-100 hover:scale-[1.02] transition-all flex items-center justify-center gap-2 mt-4"
            >
              Entrar Agora
              <ArrowRight size={20} />
            </button>
          </form>

          <div className="mt-8 pt-8 border-t border-gray-50 text-center">
            <p className="text-sm text-gray-500 font-medium">
              Não tem uma conta?{' '}
              <Link to="/register" className="text-[#ee4d2d] font-black hover:underline uppercase tracking-tighter">
                Cadastre-se Grátis
              </Link>
            </p>
          </div>
        </div>
        
        <div className="mt-8 flex justify-center gap-6 text-[10px] font-black text-gray-300 uppercase tracking-widest">
          <span>Privacidade</span>
          <span>Termos</span>
          <span>Suporte</span>
        </div>
      </div>

      {isResetting && (
        <div className="fixed inset-0 bg-black/40 backdrop-blur-sm z-[200] flex items-center justify-center p-4">
           <div className="bg-white p-8 rounded-3xl shadow-2xl flex flex-col items-center gap-4 text-center">
              <div className="bg-orange-100 p-4 rounded-full text-[#ee4d2d] animate-bounce">
                <Lock size={32} />
              </div>
              <h3 className="text-xl font-black uppercase italic">Resetando Senha</h3>
              <p className="text-sm text-gray-500">Aguarde enquanto geramos seu código de segurança...</p>
              <div className="w-12 h-1.5 bg-gray-100 rounded-full overflow-hidden">
                <div className="h-full bg-[#ee4d2d] animate-progress w-full"></div>
              </div>
           </div>
        </div>
      )}
    </div>
  );
};

export default Login;
