
import React, { useState, useEffect } from 'react';
import { 
  ShieldCheck, 
  Package, 
  ShoppingBag, 
  Users, 
  CheckCircle2, 
  XCircle, 
  Eye, 
  Video,
  Clock,
  LayoutDashboard,
  Filter,
  Search,
  MoreVertical,
  ChevronRight,
  TrendingUp,
  AlertCircle,
  Lock,
  Flag,
  UserCheck,
  UserX,
  ShieldAlert,
  Save,
  Key,
  // Fix: Added Loader2 to imports from lucide-react
  Loader2
} from 'lucide-react';
import { Product, Order, ProductStatus, User } from '../types';

interface AdminDashboardProps {
  products: Product[];
  orders: Order[];
  onUpdateStatus: (id: string, status: ProductStatus) => void;
  currentUser: User | null;
}

const AdminDashboard: React.FC<AdminDashboardProps> = ({ products, orders, onUpdateStatus, currentUser }) => {
  const [activeTab, setActiveTab] = useState<'products' | 'orders' | 'users' | 'security'>('products');
  const [filter, setFilter] = useState<ProductStatus | 'ALL'>('ALL');
  const [allUsers, setAllUsers] = useState<User[]>([]);
  
  // Security form states
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [saveStatus, setSaveStatus] = useState<'idle' | 'saving' | 'success' | 'error'>('idle');

  useEffect(() => {
    const stored = JSON.parse(localStorage.getItem('safe_shop_registered_users') || '[]');
    setAllUsers(stored);
  }, []);

  const pendingProducts = products.filter(p => p.status === ProductStatus.PENDING);
  const filteredProducts = filter === 'ALL' ? products : products.filter(p => p.status === filter);

  const handlePasswordChange = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newPassword || newPassword !== confirmPassword) {
      setSaveStatus('error');
      return;
    }

    setSaveStatus('saving');
    setTimeout(() => {
      // In a real app, this would be an API call.
      // For this demo, we update the currentUser in localStorage if it's an admin
      const storedUser = JSON.parse(localStorage.getItem('safe_shop_user') || '{}');
      if (storedUser.email === currentUser?.email) {
        storedUser.password = newPassword;
        localStorage.setItem('safe_shop_user', JSON.stringify(storedUser));
        
        // Also update the static admin list if needed or the registered users list
        const registered = JSON.parse(localStorage.getItem('safe_shop_registered_users') || '[]');
        const updatedRegistered = registered.map((u: User) => 
          u.email === currentUser?.email ? { ...u, password: newPassword } : u
        );
        localStorage.setItem('safe_shop_registered_users', JSON.stringify(updatedRegistered));
      }
      
      setSaveStatus('success');
      setNewPassword('');
      setConfirmPassword('');
      setTimeout(() => setSaveStatus('idle'), 3000);
    }, 1500);
  };

  return (
    <div className="min-h-screen bg-gray-50 pb-20">
      {/* Admin Header */}
      <div className="bg-white border-b border-gray-100 shadow-sm sticky top-[132px] sm:top-[128px] z-30">
        <div className="container mx-auto px-4 py-4 flex flex-col md:flex-row justify-between items-center gap-4">
          <div className="flex items-center gap-3">
            <div className="bg-yellow-400 text-black p-2 rounded-xl">
              <ShieldAlert size={20} />
            </div>
            <div>
              <h1 className="text-lg font-black uppercase italic text-gray-800 tracking-tight leading-none">Admin Central</h1>
              <span className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">Acesso Restrito: {currentUser?.name}</span>
            </div>
          </div>

          <div className="flex bg-gray-100 p-1 rounded-2xl overflow-x-auto max-w-full">
            <button 
              onClick={() => setActiveTab('products')}
              className={`px-4 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all whitespace-nowrap ${activeTab === 'products' ? 'bg-white shadow-sm text-[#ee4d2d]' : 'text-gray-500'}`}
            >
              Produtos
            </button>
            <button 
              onClick={() => setActiveTab('orders')}
              className={`px-4 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all whitespace-nowrap ${activeTab === 'orders' ? 'bg-white shadow-sm text-[#ee4d2d]' : 'text-gray-500'}`}
            >
              Vendas
            </button>
            <button 
              onClick={() => setActiveTab('users')}
              className={`px-4 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all whitespace-nowrap ${activeTab === 'users' ? 'bg-white shadow-sm text-[#ee4d2d]' : 'text-gray-500'}`}
            >
              Usuários
            </button>
            <button 
              onClick={() => setActiveTab('security')}
              className={`px-4 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all whitespace-nowrap ${activeTab === 'security' ? 'bg-white shadow-sm text-[#ee4d2d]' : 'text-gray-500'}`}
            >
              Segurança
            </button>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8">
        {/* Stats Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
           {[
             { label: 'Aprovação Pendente', value: pendingProducts.length, icon: <Clock size={24} />, color: 'orange' },
             { label: 'Total de Vendas', value: orders.length, icon: <TrendingUp size={24} />, color: 'blue' },
             { label: 'Produtos Ativos', value: products.filter(p => p.status === ProductStatus.APPROVED).length, icon: <CheckCircle2 size={24} />, color: 'green' },
             { label: 'Usuários Registrados', value: allUsers.length + 2, icon: <Users size={24} />, color: 'purple' }
           ].map((stat, i) => (
             <div key={i} className="bg-white p-6 rounded-3xl shadow-sm border border-gray-100 flex items-center justify-between">
                <div>
                   <p className="text-[10px] font-black uppercase text-gray-400 tracking-widest mb-1">{stat.label}</p>
                   <p className="text-3xl font-black text-gray-800">{stat.value}</p>
                </div>
                <div className={`p-4 rounded-2xl bg-gray-50 text-gray-400`}>
                   {stat.icon}
                </div>
             </div>
           ))}
        </div>

        {activeTab === 'products' && (
          <div className="bg-white rounded-3xl shadow-sm border border-gray-100 overflow-hidden">
             <div className="p-6 border-b border-gray-50 flex justify-between items-center bg-gray-50/50">
                <h2 className="font-black uppercase italic tracking-tight text-gray-700">Gerenciar Listagens</h2>
                <select 
                  value={filter}
                  onChange={(e) => setFilter(e.target.value as any)}
                  className="bg-white border border-gray-100 rounded-xl px-4 py-2 text-xs font-bold outline-none"
                >
                  <option value="ALL">Todos os Estados</option>
                  <option value={ProductStatus.PENDING}>Pendentes</option>
                  <option value={ProductStatus.APPROVED}>Aprovados</option>
                  <option value={ProductStatus.REJECTED}>Rejeitados</option>
                </select>
             </div>
             <div className="overflow-x-auto">
                <table className="w-full text-left">
                   <thead className="bg-gray-50/50 text-[10px] font-black uppercase text-gray-400 tracking-[0.2em]">
                      <tr>
                         <th className="px-8 py-4">Produto</th>
                         <th className="px-6 py-4">Vendedor</th>
                         <th className="px-6 py-4">Preço</th>
                         <th className="px-6 py-4">Status</th>
                         <th className="px-8 py-4 text-right">Ações</th>
                      </tr>
                   </thead>
                   <tbody className="divide-y divide-gray-50">
                      {filteredProducts.map((p) => (
                        <tr key={p.id} className="hover:bg-gray-50/50 transition">
                           <td className="px-8 py-4">
                              <div className="flex items-center gap-4">
                                 <div className="w-12 h-12 rounded-xl bg-gray-100 overflow-hidden shrink-0">
                                    <img src={p.images[0]} className="w-full h-full object-cover" />
                                 </div>
                                 <div>
                                    <p className="text-sm font-bold text-gray-800 line-clamp-1">{p.title}</p>
                                    <p className="text-[10px] text-gray-400 font-medium">ID: {p.id}</p>
                                 </div>
                              </div>
                           </td>
                           <td className="px-6 py-4 text-xs font-bold">Vendedor #{p.sellerId}</td>
                           <td className="px-6 py-4 text-sm font-black text-[#ee4d2d]">R$ {p.price.toLocaleString('pt-BR')}</td>
                           <td className="px-6 py-4">
                              <span className={`text-[9px] font-black uppercase px-2 py-1 rounded-full ${
                                 p.status === ProductStatus.APPROVED ? 'bg-green-100 text-green-700' :
                                 p.status === ProductStatus.PENDING ? 'bg-orange-100 text-orange-700' : 'bg-red-100 text-red-700'
                              }`}>
                                 {p.status}
                              </span>
                           </td>
                           <td className="px-8 py-4 text-right">
                              <div className="flex justify-end gap-2">
                                 {p.status === ProductStatus.PENDING && (
                                   <>
                                      <button onClick={() => onUpdateStatus(p.id, ProductStatus.APPROVED)} className="bg-green-600 text-white p-2 rounded-xl hover:scale-110 transition"><CheckCircle2 size={16} /></button>
                                      <button onClick={() => onUpdateStatus(p.id, ProductStatus.REJECTED)} className="bg-red-600 text-white p-2 rounded-xl hover:scale-110 transition"><XCircle size={16} /></button>
                                   </>
                                 )}
                                 <button className="bg-gray-100 text-gray-600 p-2 rounded-xl"><Eye size={16} /></button>
                              </div>
                           </td>
                        </tr>
                      ))}
                   </tbody>
                </table>
             </div>
          </div>
        )}

        {activeTab === 'orders' && (
          <div className="bg-white rounded-3xl shadow-sm border border-gray-100 p-12 text-center">
             <ShoppingBag className="mx-auto text-gray-200 mb-4" size={48} />
             <h3 className="text-xl font-black text-gray-800 uppercase italic">Fluxo de Pagamentos</h3>
             <div className="mt-8 grid gap-4 max-w-3xl mx-auto">
                {orders.length === 0 ? <p className="text-gray-400">Nenhuma venda registrada ainda.</p> : orders.map(o => (
                  <div key={o.id} className="bg-gray-50 p-6 rounded-3xl flex items-center justify-between text-left border border-gray-100">
                     <div className="flex items-center gap-4">
                        <div className="bg-blue-100 p-3 rounded-2xl text-blue-600"><ShoppingBag size={20}/></div>
                        <div>
                           <p className="text-sm font-black text-gray-800">Pedido #{o.id}</p>
                           <p className="text-[10px] text-gray-400 font-bold uppercase tracking-widest">{new Date(o.createdAt).toLocaleDateString()} • Comprador: {o.buyerId}</p>
                        </div>
                     </div>
                     <div className="text-right">
                        <p className="text-lg font-black text-[#ee4d2d]">R$ {o.amount.toLocaleString('pt-BR')}</p>
                        <span className="text-[9px] font-black uppercase px-2 py-0.5 bg-blue-100 text-blue-700 rounded-full">{o.paymentStatus}</span>
                     </div>
                  </div>
                ))}
             </div>
          </div>
        )}

        {activeTab === 'users' && (
          <div className="bg-white rounded-3xl shadow-sm border border-gray-100 overflow-hidden">
             <div className="p-6 border-b border-gray-50 flex justify-between items-center bg-gray-50/50">
                <h2 className="font-black uppercase italic tracking-tight text-gray-700">Controle de Usuários</h2>
                <div className="relative">
                   <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
                   <input type="text" placeholder="Buscar e-mail..." className="pl-9 pr-4 py-2 border rounded-xl text-xs outline-none focus:ring-1 focus:ring-[#ee4d2d]" />
                </div>
             </div>
             <div className="overflow-x-auto">
                <table className="w-full text-left">
                   <thead className="bg-gray-50/50 text-[10px] font-black uppercase text-gray-400 tracking-[0.2em]">
                      <tr>
                         <th className="px-8 py-4">Usuário</th>
                         <th className="px-6 py-4">E-mail</th>
                         <th className="px-6 py-4">Saldo</th>
                         <th className="px-6 py-4">Papel</th>
                         <th className="px-8 py-4 text-right">Ações</th>
                      </tr>
                   </thead>
                   <tbody className="divide-y divide-gray-50">
                      {/* Standard Admins */}
                      {[
                        { name: 'Edinaldo Georgez', email: 'Edinaldogeorgez@gmail.com', role: 'ADMIN' },
                        { name: 'Jonas Georges', email: 'Jonasgeorges730@gmail.com', role: 'ADMIN' }
                      ].map((adm, i) => (
                        <tr key={i} className="bg-yellow-50/30">
                           <td className="px-8 py-4 flex items-center gap-3">
                              <div className="w-8 h-8 rounded-full bg-yellow-400 flex items-center justify-center font-bold text-[10px]">{adm.name.charAt(0)}</div>
                              <span className="text-xs font-bold">{adm.name}</span>
                           </td>
                           <td className="px-6 py-4 text-xs font-medium text-gray-500">{adm.email}</td>
                           <td className="px-6 py-4 text-xs font-black">R$ 10.000,00</td>
                           <td className="px-6 py-4"><span className="text-[8px] font-black bg-yellow-100 text-yellow-700 px-2 py-0.5 rounded-full uppercase">SUPER ADMIN</span></td>
                           <td className="px-8 py-4 text-right"><ShieldCheck size={16} className="text-yellow-500 ml-auto" /></td>
                        </tr>
                      ))}
                      {/* Registered Users */}
                      {allUsers.map((u) => (
                        <tr key={u.id}>
                           <td className="px-8 py-4 flex items-center gap-3">
                              <div className="w-8 h-8 rounded-full bg-gray-100 flex items-center justify-center font-bold text-[10px]">{u.name.charAt(0)}</div>
                              <span className="text-xs font-bold">{u.name}</span>
                           </td>
                           <td className="px-6 py-4 text-xs font-medium text-gray-500">{u.email}</td>
                           <td className="px-6 py-4 text-xs font-black">R$ {u.walletBalance.toLocaleString('pt-BR')}</td>
                           <td className="px-6 py-4"><span className="text-[8px] font-black bg-blue-50 text-blue-600 px-2 py-0.5 rounded-full uppercase">USER</span></td>
                           <td className="px-8 py-4 text-right">
                              <div className="flex justify-end gap-2">
                                 <button className="text-gray-400 hover:text-green-600"><UserCheck size={16}/></button>
                                 <button className="text-gray-400 hover:text-red-600"><UserX size={16}/></button>
                              </div>
                           </td>
                        </tr>
                      ))}
                   </tbody>
                </table>
             </div>
          </div>
        )}

        {activeTab === 'security' && (
          <div className="max-w-xl mx-auto">
             <div className="bg-white rounded-[2.5rem] shadow-xl border border-gray-100 overflow-hidden">
                <div className="bg-[#ee4d2d] p-8 text-white text-center">
                   <div className="bg-white/20 p-4 w-16 h-16 rounded-3xl flex items-center justify-center mx-auto mb-4">
                      <Key size={32} />
                   </div>
                   <h3 className="text-xl font-black uppercase italic tracking-tighter leading-none">Minha Segurança</h3>
                   <p className="text-[10px] font-bold uppercase tracking-widest mt-2 opacity-80">Alteração de Senha Administrativa</p>
                </div>
                
                <div className="p-10">
                   <form onSubmit={handlePasswordChange} className="space-y-6">
                      <div className="space-y-2">
                         <label className="text-[10px] font-black uppercase text-gray-400 tracking-widest px-2">Nova Senha</label>
                         <div className="relative">
                            <Lock size={18} className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-300" />
                            <input 
                              type="password"
                              required
                              value={newPassword}
                              onChange={(e) => setNewPassword(e.target.value)}
                              placeholder="Mínimo 6 caracteres"
                              className="w-full bg-gray-50 border border-gray-100 p-4 pl-12 rounded-2xl outline-none focus:ring-2 focus:ring-[#ee4d2d] transition-all"
                            />
                         </div>
                      </div>

                      <div className="space-y-2">
                         <label className="text-[10px] font-black uppercase text-gray-400 tracking-widest px-2">Confirmar Senha</label>
                         <div className="relative">
                            <Lock size={18} className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-300" />
                            <input 
                              type="password"
                              required
                              value={confirmPassword}
                              onChange={(e) => setConfirmPassword(e.target.value)}
                              placeholder="Repita a nova senha"
                              className="w-full bg-gray-50 border border-gray-100 p-4 pl-12 rounded-2xl outline-none focus:ring-2 focus:ring-[#ee4d2d] transition-all"
                            />
                         </div>
                      </div>

                      {saveStatus === 'success' && (
                        <div className="bg-green-50 text-green-700 p-4 rounded-2xl text-xs font-bold flex items-center gap-2 border border-green-100">
                           <CheckCircle2 size={16} /> Senha atualizada com sucesso!
                        </div>
                      )}

                      {saveStatus === 'error' && (
                        <div className="bg-red-50 text-red-700 p-4 rounded-2xl text-xs font-bold flex items-center gap-2 border border-red-100">
                           <AlertCircle size={16} /> As senhas não coincidem.
                        </div>
                      )}

                      <button 
                        type="submit"
                        disabled={saveStatus === 'saving'}
                        className="w-full bg-black text-white py-5 rounded-2xl font-black uppercase tracking-widest shadow-xl hover:bg-[#ee4d2d] transition-all flex items-center justify-center gap-2"
                      >
                         {saveStatus === 'saving' ? (
                           <Loader2 size={20} className="animate-spin" />
                         ) : (
                           <Save size={20} />
                         )}
                         RECOLOCAR SENHA
                      </button>
                   </form>
                </div>
                
                <div className="bg-gray-50 p-6 border-t border-gray-100">
                   <div className="flex gap-4 items-start">
                      <ShieldCheck size={24} className="text-gray-400 shrink-0" />
                      <p className="text-[10px] text-gray-400 font-medium leading-relaxed">
                        Ao alterar sua senha, sua sessão atual permanecerá ativa. No próximo login, utilize suas novas credenciais. Suas contas administradoras possuem monitoramento de segurança avançado.
                      </p>
                   </div>
                </div>
             </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default AdminDashboard;
