
import React, { useState, useRef, useEffect } from 'react';
import { MessageSquare, Send, Bot, Loader2, Minimize2, AlertTriangle } from 'lucide-react';
import { GoogleGenAI } from '@google/genai';

interface AIChatSupportProps {
  onStrike: () => void;
}

const AIChatSupport: React.FC<AIChatSupportProps> = ({ onStrike }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<{role: 'user' | 'bot' | 'system', text: string}[]>([
    { role: 'bot', text: 'Olá! Sou o Sentinela Safe-Shop. Estou aqui para suporte e moderação. Como posso ajudar?' }
  ]);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, isTyping]);

  const handleSend = async () => {
    if (!input.trim() || isTyping) return;
    const userMsg = input.trim();
    setMessages(prev => [...prev, { role: 'user', text: userMsg }]);
    setInput('');
    setIsTyping(true);

    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: [{ parts: [{ text: userMsg }] }],
        config: {
          systemInstruction: `Você é o "Sentinela Safe-Shop", assistente virtual e MODERADOR.
          
          POLÍTICAS DA PLATAFORMA:
          1. LOJA FÍSICA: Não possuímos lojas físicas. Somos um marketplace 100% digital e seguro.
          2. PRODUTOS PERMITIDOS: Armas e itens +18 são permitidos, desde que classificados corretamente (com foto borrada).
          3. PRODUTOS PROIBIDOS: Drogas de qualquer tipo são terminantemente proibidas.
          4. CONDUTA: Linguagem ofensiva ou palavrões resultam em STRIKE.
          
          SISTEMA DE STRIKES:
          - Se o usuário falar um palavrão pesado ou tentar negociar DROGAS, você deve responder com o código "[STRIKE_APPLIED]" no final da sua mensagem e aplicar uma advertência severa.
          - 3 Strikes = Banimento Automático (você não bane, o sistema detecta seu código).
          
          Dúvidas sobre pagamentos (Safe Pay) e vídeos de prova real são sua especialidade.`,
          temperature: 0.2,
        }
      });
      
      const botResponse = response.text || "";
      
      if (botResponse.includes("[STRIKE_APPLIED]")) {
        onStrike();
        const cleanText = botResponse.replace("[STRIKE_APPLIED]", "");
        setMessages(prev => [...prev, { role: 'bot', text: cleanText }, { role: 'system', text: '⚠️ VIOLAÇÃO DETECTADA: Você recebeu um STRIKE. No 3º você será banido.' }]);
      } else {
        setMessages(prev => [...prev, { role: 'bot', text: botResponse }]);
      }
    } catch (e) {
      setMessages(prev => [...prev, { role: 'bot', text: "Erro na central de moderação. Tente novamente." }]);
    } finally {
      setIsTyping(false);
    }
  };

  return (
    <>
      <button 
        onClick={() => setIsOpen(true)}
        className={`fixed bottom-6 right-24 bg-[#ee4d2d] text-white p-4 rounded-full shadow-2xl transition-all z-[90] hover:scale-110 flex items-center gap-2 font-bold ${isOpen ? 'scale-0' : 'scale-100'}`}
      >
        <MessageSquare size={24} />
        <span className="hidden sm:inline">IA Sentinela</span>
      </button>

      <div className={`fixed bottom-6 right-6 w-[90vw] sm:w-[400px] h-[550px] bg-white rounded-lg shadow-2xl flex flex-col z-[110] border border-gray-100 transition-all transform origin-bottom-right ${isOpen ? 'scale-100 translate-y-0 opacity-100' : 'scale-0 translate-y-10 opacity-0 pointer-events-none'}`}>
        <div className="bg-[#ee4d2d] p-4 text-white flex justify-between items-center rounded-t-lg">
          <div className="flex items-center gap-3">
            <Bot size={20} />
            <h3 className="font-bold text-sm">Sentinela Safe-Shop</h3>
          </div>
          <button onClick={() => setIsOpen(false)}><Minimize2 size={18} /></button>
        </div>

        <div ref={scrollRef} className="flex-grow overflow-y-auto p-4 space-y-4 bg-gray-50/50">
          {messages.map((m, i) => (
            <div key={i} className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}>
              <div className={`max-w-[85%] p-3 rounded-2xl text-[13px] leading-relaxed shadow-sm ${
                m.role === 'user' ? 'bg-[#ee4d2d] text-white rounded-br-none' : 
                m.role === 'system' ? 'bg-yellow-100 text-yellow-800 border border-yellow-200 font-bold' :
                'bg-white text-gray-800 rounded-bl-none border border-gray-100'
              }`}>
                {m.text}
              </div>
            </div>
          ))}
          {isTyping && (
            <div className="flex justify-start items-center gap-2 text-gray-400 text-xs">
              <Loader2 className="w-4 h-4 animate-spin text-[#ee4d2d]" />
              Analisando mensagem...
            </div>
          )}
        </div>

        <div className="p-4 border-t bg-white rounded-b-lg">
          <div className="flex gap-2 bg-gray-100 p-2 rounded-full focus-within:bg-white focus-within:ring-2 focus-within:ring-[#ee4d2d]">
            <input 
              type="text" 
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && handleSend()}
              placeholder="Digite aqui..."
              className="flex-grow bg-transparent border-none outline-none px-3 text-sm"
            />
            <button onClick={handleSend} disabled={isTyping} className="bg-[#ee4d2d] text-white p-2 rounded-full">
              <Send size={18} />
            </button>
          </div>
        </div>
      </div>
    </>
  );
};

export default AIChatSupport;
