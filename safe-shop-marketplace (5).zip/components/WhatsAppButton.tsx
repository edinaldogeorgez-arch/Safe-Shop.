
import React from 'react';
import { Phone } from 'lucide-react';

const WhatsAppButton: React.FC = () => {
  return (
    <a 
      href="https://wa.me/554588061597?text=Olá! Preciso de suporte com minha venda/compra na Safe-Shop."
      target="_blank"
      rel="noopener noreferrer"
      className="fixed bottom-6 right-6 bg-[#25D366] text-white p-4 rounded-full shadow-2xl flex items-center gap-3 hover:scale-110 transition-all z-[100] group"
    >
      <div className="relative">
        <svg 
          viewBox="0 0 24 24" 
          width="32" 
          height="32" 
          stroke="currentColor" 
          strokeWidth="0" 
          fill="currentColor"
        >
          <path d="M17.472 14.382c-.301-.15-1.767-.872-2.04-.971-.272-.099-.47-.15-.67.15-.199.301-.77.971-.943 1.171-.173.2-.347.225-.648.075-.301-.15-1.269-.467-2.418-1.493-.892-.795-1.494-1.777-1.67-2.078-.176-.3-.018-.462.133-.611.135-.134.301-.35.45-.524.15-.173.2-.299.301-.499.1-.199.05-.375-.025-.524-.075-.15-.67-1.613-.918-2.213-.242-.589-.487-.509-.67-.518-.173-.008-.371-.01-.57-.01-.199 0-.523.075-.797.374-.274.299-1.046 1.023-1.046 2.497 0 1.474 1.074 2.895 1.223 3.094.149.199 2.112 3.224 5.115 4.524.714.309 1.271.494 1.705.632.717.227 1.369.195 1.885.118.575-.085 1.767-.721 2.016-1.417.25-.697.25-1.296.175-1.417-.075-.121-.272-.199-.573-.349h-.012zM12.004 0C5.374 0 0 5.374 0 12.004c0 2.116.549 4.103 1.512 5.832L0 24l6.335-1.662c1.714.935 3.674 1.47 5.669 1.47 6.63 0 12.004-5.374 12.004-12.004C24.008 5.374 18.634 0 12.004 0z"/>
        </svg>
      </div>
      <div className="flex flex-col leading-none pr-2">
        <span className="text-[10px] uppercase font-black opacity-80 tracking-widest">Suporte 24h</span>
        <span className="font-bold">WhatsApp</span>
      </div>
    </a>
  );
};

export default WhatsAppButton;
